<div id="gameSection" style=" background: none repeat scroll 0 0 white;
     color: green;
     font-size: 24px;
     padding-bottom: 100px;
     padding-top: 100px;
     text-align: center;">
    Project is successfully submitted!
</div>