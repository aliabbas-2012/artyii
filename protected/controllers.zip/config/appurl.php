<?php

return array(
    'adsignin' => 'admin/signin/',
    'adlogout' => 'admin/logout/',
    'adusers' => 'admin/users/',
    'addeleteuser' => 'admin/deleteuser/key',
    'adonlineusers' => 'admin/onlineusers/',
    'adnewuser' => 'admin/newuser/',
    'adcategories' => 'admin/categories/',
    'adnewcategory' => 'admin/newcategory/',
    'adproviders' => 'admin/providers/',
    'adnewprovider' => 'admin/newprovider/',
    'adgames' => 'admin/games/',
    'adnewgame' => 'admin/newgame/',
    'adgameorder' => 'admin/ordergames/',
    'adeditgame' => 'admin/editgame/key',
    'addeletegame' => 'admin/deletegame/key',
    'aderror' => 'admin/error/',
    'adplayerwisereport' => 'admin/reportplayerwise/',
    'adgamewisereport' => 'admin/reportgamewise/',
    'adsettings' => 'admin/settings/',
    
    
    'si_index' => 'site/',
    'site_root' => 'site/',
    'si_play_game' => 'site/play/i',
    'si_contactus' => 'site/contactus',
    'si_aboutus' => 'site/aboutus',
    'si_responsibly' => 'site/responsibly',
    'si_tos' => 'site/tos',
    'si_privacy' => 'site/privacy',
    
    'si_signup' => 'site/signup',
    'si_signin' => 'site/signin',
    'si_logout' => 'site/logout',
    'si_forgotpass' => 'site/forgotpass',
);
