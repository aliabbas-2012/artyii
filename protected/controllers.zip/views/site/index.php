<?php  if(isset($models) && !empty($models) && count($models)>0){
 $smodel = Psettings::model()->findByAttributes(array('tps_id' => 1));
 for($i=0;$i<count($models);$i++){?>
<div class="gameBox">
    <p><?php echo $models[$i]->tg_name;?></p>
    <div class="gameBoxImage">
        <div class=" <?php if($smodel->tps_animation==1){?>imagechange-3d image-hover hover<?php } ?>">
            <?php if($smodel->tps_animation==1){?>
            <div class="imagechange-3d-inner image-hover hover">
                <div class="imgchange-1">
                    <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_play_game']).'/'.$models[$i]->tg_slug; ?>" class="lightbox">
                        <img class="lazy" src="<?php echo BASE_URL.'/images/'.'default.jpg'; ?>" data-original="<?php echo BASE_URL; ?>/cdnimg/<?php echo $models[$i]->tg_thumb;?>" title="<?php echo $models[$i]->tg_name;?>" alt="<?php echo $models[$i]->tg_name;?>"> 
                    </a>
                </div>
                <div class="imgchange-2">
                    <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_play_game']).'/'.$models[$i]->tg_slug; ?>" class="lightbox">
                        <img class="lazy" src="<?php echo BASE_URL.'/images/'.'default.jpg'; ?>" data-original="<?php echo BASE_URL; ?>/cdnimg/<?php echo $models[$i]->tg_thumb;?>" title="<?php echo $models[$i]->tg_name;?>" alt="<?php echo $models[$i]->tg_name;?>"> 
                    </a>
                </div>
            </div>
             <?php }else{ ?>
            
                <div class="imagechange-3d-inner">
                    <div class="">
                        <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_play_game']).'/'.$models[$i]->tg_slug; ?>" class="lightbox">
                            <img class="lazy" src="<?php echo BASE_URL.'/images/'.'default.jpg'; ?>" data-original="<?php echo BASE_URL; ?>/cdnimg/<?php echo $models[$i]->tg_thumb;?>" title="<?php echo $models[$i]->tg_name;?>" alt="<?php echo $models[$i]->tg_name;?>"> 
                        </a>
                    </div>
                </div>
            
             <?php } ?>
        </div>
    </div>
</div>
<?php } }?>
