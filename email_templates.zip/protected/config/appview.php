<?php
return array(
    'adsignin' => 'adsignin',
    'adusers' => 'adusers',
    'aderror' => 'error',
    'adprojects' => 'adprojects',
    
    
    'si_index' => 'index',
    'site_root' => 'index',
    'si_play_game' => 'si_play_game',
    'si_contactus' => 'contactus',
    'si_aboutus' => 'aboutus',
    'si_responsibly' => 'responsibly',
    'si_tos' => 'tos',
    'si_privacy' => 'privacy',
    
    'si_signup' => 'signup',
    'si_signin' => 'signin',
    'si_forgotpass' => 'forgotpass',
    'verify_view'=>'verify_view',
    'si_dashboard' => 'dashboard',
    'change_password'=>'change_password',
    'active_password'=>'active_password',
    'si_error'=>'si_error',
    
   
);