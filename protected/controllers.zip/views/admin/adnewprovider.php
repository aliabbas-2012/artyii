<style>
    .info {
      background-color: #F0F7FD;
      border-color: #D0E3F0;
      padding:10px;
      font-size:16px;
      color:red;
    }
</style>
<script>
    $(document).ready(function() {
        $("#frmBrand").validate({
            rules:
            {
                tp_name: {
                    required:true,
                    minlength:2
                }
            },
            messages: {
                tp_name: {
                    required:"This field is required!"
                }
            }
        });
    });
</script>
<div id="pageTitle">
    <h2 class="thick-title page-title-bar">New Provider</h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div>
                            <?php if(Yii::app()->user->hasFlash('success')):?>
                                <div class="info">
                                    <?php echo Yii::app()->user->getFlash('success'); ?>
                                </div>
                            <?php endif; ?>
                            <form enctype="multipart/form-data" name="frmBrand" id="frmBrand" action="" method="post">
                                <div class="form-group">
                                    <label for="tp_name">Provider Name</label>
                                    <input type="text" class="form-control" id="tp_name" name="tp_name" placeholder="e.g. Net Ent">
                                </div>
                                
                                
                                <div class="form-group">
                                    <button type="submit" id="btnSubmit" name="btnSubmit" class="btn btn-info">Create</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="app-callout app-callout-info">
                            <h4>Notes</h4>
                            <p>This section is only accessible for Administrator.</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>