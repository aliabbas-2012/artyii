<?php

class RequireLogin extends CBehavior {

    public function attach($owner) {

        $owner->attachEventHandler('onBeginRequest', array($this, 'handleBeginRequest'));
    }

    /**
     * Check authentication and redirect user to activity page if not logged in.
     * @param type $event 
     */
    public function handleBeginRequest($event) {
        //session_start();
        if (isset($_SESSION['browser_country'])) {
            //$_SESSION['browser_country'] = 'Bangladesh';
        } else {
            $client = @$_SERVER['HTTP_CLIENT_IP'];
            $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
            $remote = $_SERVER['REMOTE_ADDR'];
            $result = "Unknown";
            if (filter_var($client, FILTER_VALIDATE_IP)) {
                $ip = $client;
            } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
                $ip = $forward;
            } else {
                $ip = $remote;
            }
            $result = 'Bangladesh';
            $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));

            if ($ip_data && $ip_data->geoplugin_countryName != null) {
                $result = $ip_data->geoplugin_countryName;
                //$model->tu_long_country = $result;
            }
            $_SESSION['browser_country'] = $result;
        }
        $route = Yii::app()->getUrlManager()->parseUrl(Yii::app()->getRequest());
        //echo $route;exit();
        $routepieces = explode("/", $route);
        if (in_array($routepieces[0], array('site', ''))) { /// Push login free controller name here
            $site_mode = Helpers::siteMode();
            if ($site_mode) {
                if (!in_array($route, array('site/message'))) {
                    $url = Yii::app()->createUrl(Yii::app()->params['AppUrls']['fr_message']);
                    Yii::app()->request->redirect($url);
                }
            }
        } else {
            if (isset(Yii::app()->user->useremail) && Yii::app()->user->useremail) {
                if (Yii::app()->user->admin != 3 && $routepieces[0] == 'admin') {
                    $url = Yii::app()->createUrl(Yii::app()->params['AppUrls']['si_index']);
                    Yii::app()->request->redirect($url);
                }
                if (isset(Yii::app()->user->password) && !Yii::app()->user->password) {
                    if (in_array($route, array('site/changepassword', 'admin/changepassword', 'admin/logout', 'site/logout', 'site/passwordcheck'))) {
                        
                    } else {
                        $url = Yii::app()->createUrl(Yii::app()->params['AppUrls']['si_index']);
                        Yii::app()->request->redirect($url);
                    }
                } else if (in_array($route, array('site/verifyuser', 'admin/signin', 'site/signup', 'site/emailcheck'))) {
                    $url = Yii::app()->createUrl(Yii::app()->params['AppUrls']['si_index']);
                    Yii::app()->request->redirect($url);
                }
            } else {
                
            }
        }
    }

    public function handlelogout() {
        $url = Yii::app()->createUrl('user/logout');
        Yii::app()->request->redirect($url);
    }

    /**
     *
     * @param type $event 
     */
    public function handleBrowserCheck($event) {

        //echo $browserName = Yii::app()->browser->getName();
    }

    /**
     *
     * @param type $event 
     */
    public function handleImports($event) {
        
    }

    /**
     *
     * @param type $event 
     */
    public function handleLoadTimeZone($event) {
        
    }

    /**
     *
     * @param type $event 
     */
    public function handleCheckAndUpdateCurrencyRates($event) {
        
    }

    /**
     *
     * @param type $event 
     */
    public function handleResolveCustomData($event) {
        
    }

    /**
     *
     * @param type $event 
     */
    public function handleLoadLanguage($event) {
        
    }

    /**
     *
     * @param type $event 
     */
    public function handleClearCache($event) {
        
    }

}

?>