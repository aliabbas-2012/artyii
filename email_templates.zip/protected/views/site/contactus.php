<div id="gameSection">
    <div class="textblock">
        <h1>Contact Us</h1>
        <p>If you have any questions, please read carefully all information provided on this website. In particular take a close look on our <a href="/pages.faq.aqp">FAQ page</a> (frequently asked questions), the game rules of each game and the <a href="/pages.TsAndCs.aqp">Terms &amp; Conditions</a> of our service.</p><p>If you can't find the answer to your question, please contact us by telephone or via e-mail:</p><p><b>E-mail:</b> <a href="mailto:support@plus-five.com">support@plus-five.com</a><br><b>Internet:</b> <a href="http://www.cleocasino.com">http://www.cleocasino.com</a></p><p>Call <strong>0844 567 6148</strong> from the UK. <br> From outside the UK call <strong>+44 844 567 6148</strong>.</p><p>All customer queries will be answered within two working days.</p><p>Please Note: For security reasons our call center staff do not have access to players personal data or gaming history, there aim is to provide support and when necessary forward your query to the relevant department within the casino.
        </p>
    </div>
</div>