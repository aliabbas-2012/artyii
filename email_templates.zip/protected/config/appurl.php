<?php

return array(
    'adsignin' => 'admin/signin/',
    'adlogout' => 'admin/logout/',
    'adusers' => 'admin/users/',
    'addeleteuser' => 'admin/deleteuser/key',
    'aderror' => 'admin/error/',
    'adprojects' => 'admin/projects/',
    
    
    
    'si_index' => 'site/',
    'site_root' => 'site/',
    'si_contactus' => 'site/contactus',
    'si_aboutus' => 'site/aboutus',
    'si_responsibly' => 'site/responsibly',
    'si_tos' => 'site/tos',
    'si_privacy' => 'site/privacy',
    
    'si_signup' => 'site/signup',
    'si_signin' => 'site/signin',
    'si_logout' => 'site/logout',
    'si_dashboard' => 'site/dashboard',
    'si_forgotpass' => 'site/forgotpass',
);
