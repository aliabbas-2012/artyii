<div id="pageTitle">
    <h2 class="thick-title page-title-bar">Category List</h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <form enctype="multipart/form-data" name="frmPhoneModel" id="frmPhoneModel" action="" method="post">
                            <input type="text" class="form-control" id="txtSearchBrand" name="txtSearchBrand" placeholder="Search Category">
                        </form>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="app-grid-title">
                            <h4>Total <?php echo $total;?></h4>
                            <div class="tools">
                                <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['adnewcategory']); ?>">Create New</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(isset($models) && !empty($models) && count($models)>0){?>
                <div class="app-scrollable">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 20%;">Name</th>
                                <th style="width: 15%;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for($i=0;$i<count($models);$i++){?>
                            <tr>
                                <td><?php echo $models[$i]->tc_name;?></td>
                                <td class="text-right">
                                    <a href="javascript://">Edit</a>
                                    <a href="javascript://">Delete</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php } ?>
                <div style="margin-top:20px;">

                    <?php
                    $this->widget('CLinkPager', array(
                        'pages' => $pages,
                    ))
                    ?>

                </div>
            </div>
        </div>
    </div>
</div>