<style>
    .info {
        background-color: #F0F7FD;
        border-color: #D0E3F0;
        padding:10px;
        font-size:16px;
        color:red;
    }
</style>
<script>
    $(document).ready(function() {
        $("#frmBrand").validate({
            rules:
            {
                tg_name: {
                    required: true,
                    minlength: 2
                },
                tg_des: {
                    required: true
                },
                tg_iurl: {
                    required: true
                },
                tg_width: {
                    required: true,
                    number: true
                },
                tg_height: {
                    required: true,
                    number: true
                },
                tg_cat: {
                    required: true
                },
                tg_pro: {
                    required: true
                },
                tg_thumb: {
                    required: true
                }
            }
        });
    });
</script>
<div id="pageTitle">
    <h2 class="thick-title page-title-bar">New Game</h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div>
                            <?php if (Yii::app()->user->hasFlash('success')): ?>
                                <div class="info">
                                    <?php echo Yii::app()->user->getFlash('success'); ?>
                                </div>
                            <?php endif; ?>
                            <form enctype="multipart/form-data" name="frmBrand" id="frmBrand" action="" method="post">
                                <div class="form-group">
                                    <label for="tg_name">Name</label>
                                    <input type="text" class="form-control" id="tg_name" name="tg_name" placeholder="e.g. Reel Rush">
                                </div>
                                <div class="form-group">
                                    <label for="tg_des">Description</label>
                                    <textarea rows="2" cols="50" class="form-control" id="tg_des" name="tg_des" placeholder="e.g. Its a Rush game!"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="tg_iurl">Iframe URL</label>
                                    <input type="text" class="form-control" id="tg_iurl" name="tg_iurl" placeholder="http://www.netent.com/games/slots/reelrush/?fullscreen">
                                </div>
                                <div class="form-group">
                                    <label for="tg_width">Iframe Width</label>
                                    <input type="text" class="form-control" id="tg_width" name="tg_width" value="800" placeholder="e.g. 800">
                                </div>
                                <div class="form-group">
                                    <label for="tg_height">Iframe Height</label>
                                    <input type="text" class="form-control" id="tg_height" name="tg_height" value="600" placeholder="e.g. 600">
                                </div>

                                <div class="form-group">
                                    <label for="tg_cat">Category</label>
                                    <select id="tg_cat" name="tg_cat" class="form-control">
                                        <option value="">Select Category</option>
                                        <?php if(isset($categorylist) && !empty($categorylist) && count($categorylist)>0){?>
                                            <?php for ($i = 0; $i < count($categorylist); $i++) { ?>
                                                <option <?php if($categorylist[$i]->tc_name=='Slots') echo "selected";?> value="<?php echo $categorylist[$i]->tc_id; ?>"><?php echo $categorylist[$i]->tc_name; ?></option>
                                            <?php } ?>
                                        <?php } ?>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="tg_pro">Provider</label>
                                    <select id="tg_pro" name="tg_pro" class="form-control">
                                        <option value="">Select Provider</option>
                                        <?php if(isset($providerlist) && !empty($providerlist) && count($providerlist)>0){?>
                                            <?php for ($i = 0; $i < count($providerlist); $i++) { ?>
                                                <option value="<?php echo $providerlist[$i]->tp_id; ?>"><?php echo $providerlist[$i]->tp_name; ?></option>
                                            <?php } ?>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="tg_block">Block Country</label><br/>
                                    <?php if (isset($countrylist) && !empty($countrylist) && count($countrylist) > 0) { ?>
                                        <?php for ($i = 0; $i < count($countrylist); $i++) { ?>
                                            <input type="checkbox" id="tg_block[]" name="tg_block[]" value="<?php echo $countrylist[$i]->id; ?>"> <?php echo $countrylist[$i]->name; ?>
                                        <?php } ?>
                                    <?php } ?>
                                </div>
                                
                                <div class="form-group">
                                    <label for="tg_thumb">Thumbnail (jpg,png,gif and jpeg)</label>
                                    <input type="file" name="tg_thumb" id="tg_thumb">
                                </div>
                                
                                 <div class="form-group">
                                    <label for="tg_rthumb">Rotation Thumbnail (jpg,png,gif and jpeg)</label>
                                    <input type="file" name="tg_rthumb" id="tg_rthumb">
                                 </div>
                                

                                <div class="form-group">
                                    <button type="submit" id="btnSubmit" name="btnSubmit" class="btn btn-info">Create</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="app-callout app-callout-info">
                            <h4>Notes</h4>
                            <p>This section is only accessible for Administrator.</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>