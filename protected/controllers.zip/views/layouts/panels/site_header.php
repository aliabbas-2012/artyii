<!DOCTYPE html>
<html lang="en">
    <head>

        <title>Free Games</title> 
        <link href="<?php echo BASE_URL; ?>/css/style.css?t=1" rel="stylesheet">
        <link href="<?php echo BASE_URL; ?>/css/upload.css?t=1" rel="stylesheet">
        <script src="<?php echo BASE_URL; ?>/js/jquery-1.8.2.min.js?t=1"></script>
        <script src="<?php echo BASE_URL; ?>/js/jquery.validate.js?t=1"></script>
        <script src="http://demos.flesler.com/jquery/scrollTo/js/jquery.scrollTo-min.js"></script>
        <script src="<?php echo BASE_URL; ?>/js/jquery.lazyload.js?t=1"></script>
        
    </head>       

    <body> 