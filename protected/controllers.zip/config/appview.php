<?php
return array(
    'adsignin' => 'adsignin',
    'adusers' => 'adusers',
    'adonlineusers' => 'adonlineusers',
    'adcategories' => 'adcategories',
    'adnewcategory' => 'adnewcategory',
    'adproviders' => 'adproviders',
    'adnewprovider' => 'adnewprovider',
    'adgames' => 'adgames',
    'adordergames' => 'adordergames',
    'adnewgame' => 'adnewgame',
    'adeditgame' => 'adeditgame',
    'adusers' => 'adusers',
    'aderror' => 'error',
    'adplayerwisereport' => 'adplayerwisereport',
    'adgamewisereport' => 'adgamewisereport',
    'adsettings' => 'adsettings',
    
    'si_index' => 'index',
    'site_root' => 'index',
    'si_play_game' => 'si_play_game',
    'si_contactus' => 'contactus',
    'si_aboutus' => 'aboutus',
    'si_responsibly' => 'responsibly',
    'si_tos' => 'tos',
    'si_privacy' => 'privacy',
    
    'si_signup' => 'signup',
    'si_signin' => 'signin',
    'si_forgotpass' => 'forgotpass',
    'verify_view'=>'verify_view',
    'change_password'=>'change_password',
    'active_password'=>'active_password',
    'si_error'=>'si_error',
    
   
);