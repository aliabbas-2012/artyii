<div id="gameSection">
    <div class="textblock">
        <h1>About Us</h1>
        <p>
            <b>CleoCasino</b> 
            is a white label gaming site owned by<br><br>
            <strong>Cleo Casino Company</strong>
            <br><br><br><br><br>
            United Kingdom
        </p>
        <p>Cleo Casino Company is a marketing partner of Plus 5 Gaming Limited. Plus 5 Gaming Limited is a gaming company offering online casino games for fun and real money. Plus 5 Gaming Limited is registered and located in Malta (European Union). Plus 5 Gaming Limited owns a class 1 license from the <a title="LGA" target="_blank" href="http://www.lga.org.mt/">Lotteries and Gaming Authority (LGA)</a> in Malta and is duly approved to offer casino games certificated by the LGA.</p><p><b>CleoCasino</b> is operated on behalf of Cleo Casino Company by<br><br><strong>Plus 5 Gaming Limited</strong><br>8, Mensija Gardens<br>Ta' Marmora Street<br>SGN1832<br> Mensija L/O St. Julian's<br>Malta</p><p>E-mail: <a href="mailto:support@plus-five.com">support@plus-five.com</a><br>Internet: <a href="http://www.cleocasino.com">http://www.cleocasino.com</a></p><p>Company Registration Number: C 47089</p>
        <p>LGA Class 1 Licence Number: LGA/CL1/225/2005</p><p>LGA Class 4 Licence Number: LGA/CL4/225/2005 (Aliquantum)</p>
        <br>
    </div>
</div>