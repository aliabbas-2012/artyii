<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml"  xmlns:fb="http://ogp.me/ns/fb#">
    <head>

        <title>Artist</title> 
       
        <link href="<?php echo BASE_URL; ?>/css/style.css?t=1" rel="stylesheet">
        <link href="<?php echo BASE_URL; ?>/css/upload.css?t=1" rel="stylesheet">
        <script src="<?php echo BASE_URL; ?>/js/jquery.js?t=1"></script>
        <script type="text/javascript" src="<?php echo BASE_URL; ?>/js/jquery-ui-1.8.2.custom.min.js"></script>
        <script src="<?php echo BASE_URL; ?>/js/jquery.validate.js?t=1"></script>
        <script src="<?php echo BASE_URL; ?>/js/jquery.lazyload.js?t=1"></script>
        <script src="<?php echo BASE_URL; ?>/js/html2canvas.js?t=1"></script>
        
    </head>       

    <body> 