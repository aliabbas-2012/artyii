<div id="footer">
    <div id="footerLinks">
        <ul id="ulFootLinks">
            <li class="first">
                <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_aboutus']); ?>" title="About Us">About Us</a>
            </li> 
            <li>
                <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_contactus']); ?>" title="Contact Us">Contact Us</a>
            </li> 
            <li>
                <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_responsibly']); ?>" title="Play Responsibly">Play Responsibly</a>
            </li> 
            <li>
                <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_tos']); ?>" title="Terms &amp; Conditions">Terms &amp; Conditions</a>
            </li> 
            <li><a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_privacy']); ?>" title="Privacy Policy">Privacy Policy</a>
            </li>
        </ul>
    </div>

    <div id="payment">

    </div>


    <div id="copyright">
        <p>
            Cleo
            Casino is a marketing partner of Plus 5 Gaming Limited , Powered by 
            AliQuantum Platform operated under the following licence regulated by 
            LGA, the Lotteries and Gaming Authority of Malta: LGA/CL1/225/2005 
            (Class 1 Licence), LGA/CL4/225/2005 (Class 4 Licence)
        </p>
        <p>© Copyright 2014 Free Games - All Rights Reserved</p>
        <p>Powered by <a href="javascript://" title="Pluscoder">Pluscoder</a></p>
    </div>

</div>

<script>
    var BASE_URL = '<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_index']); ?>';
    var JBASE_URL = '<?php echo Yii::app()->request->baseUrl; ?>';
    $(function() {

        $("img.lazy").lazyload();

    });
</script>


<script>
    myTimer();
    var myVar = setInterval(function() {
        myTimer()
    }, 60000*2);
    function myTimer()
    {
        var jqxhr = $.ajax(JBASE_URL+"/site/dofunction")
        .done(function() {
            
        })
        .fail(function() {
            
        })
        .always(function() {
            
        });
    }
</script>

