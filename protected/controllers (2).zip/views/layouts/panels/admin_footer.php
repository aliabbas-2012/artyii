<footer>
    <div class="container">
        <div class="text-center">
            <span style="color: #999;"><small>Arts Portal &copy; 2014</small></span>
        </div>
    </div>
</footer>