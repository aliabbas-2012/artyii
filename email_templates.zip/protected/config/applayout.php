<?php

return array(
    'main_layout' => 'main',
    'home_layout' => 'home',
);
