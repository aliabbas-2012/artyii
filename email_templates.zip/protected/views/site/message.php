<div class="row">
    <div class="col-md-12">

        <!-- Pricing table starts -->
        <div class="csoon-page">
            <p class="soon-med">Sorry voor het ongemak! Onze site is in onderhoud.</p>                      
        </div>
    </div>
</div>