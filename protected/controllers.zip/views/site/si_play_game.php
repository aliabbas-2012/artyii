<?php  if(isset($game_details) && !empty($game_details) && count($game_details)>0){?>
<div id="gamediv">
    <iframe src="<?php echo $game_details['tg_iurl'];?>" style="width:<?php echo $game_details['tg_width'];?>px; height:<?php echo $game_details['tg_height'];?>px;" scrolling="no"></iframe>
</div>
<?php } ?>

<script>
    
    $('body').scrollTo('#horizontal-line');
</script>
