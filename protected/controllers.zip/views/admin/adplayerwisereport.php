<div id="pageTitle">
    <h2 class="thick-title page-title-bar">Report Player Wise</h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 15%;">Search User</th>
                                    <th style="width: 15%;">Country</th>
                                    <th style="width: 15%;">Game</th>
                                    <th style="width: 15%;">Order By</th>
                                </tr>
                            </thead>
                           <tbody>
                           
                            <tr>
                                <td><input type="text" class="form-control" id="txtSearchBrand" name="txtSearchBrand" placeholder="Search Player"></td>
                                <td>
                                    <select id="tg_pro" name="tg_pro" class="form-control">
                                        <option value="">All Country</option>
                                    </select>
                                </td>
                                <td>
                                    <select id="tg_pro" name="tg_pro" class="form-control">
                                        <option value="">All Game</option>
                                    </select>
                                </td>
                                <td>
                                    <select id="tg_pro" name="tg_pro" class="form-control">
                                        <option value="">Order By Game Played ASC</option>
                                        <option value="">Order By Game Played DESC</option>
                                        <option value="">Order By Times Played ASC</option>
                                        <option value="">Order By Times Played DESC</option>
                                        <option value="">Order By User Name ASC</option>
                                        <option value="">Order By User Name DESC</option>
                                    </select>
                                </td>
                            </tr>
                           
                        </tbody>
                        </table>
                    </div>
                </div>
               
                <div class="app-scrollable">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 15%;">User Name</th>
                                <th style="width: 15%;">Email</th>
                                <th style="width: 15%;">Mobile</th>
                                <th style="width: 15%;">Country Name</th>
                                <th style="width: 15%;">Created At</th>
                                <th style="width: 15%;">Unique Played</th>
                                <th style="width: 15%;">Total Played</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
               
            </div>
        </div>
    </div>
</div>