<div id="pageTitle">
    <h2 class="thick-title page-title-bar">Game List</h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <form enctype="multipart/form-data" name="frmPhoneModel" id="frmPhoneModel" action="" method="post">
                            <input type="text" class="form-control" id="txtSearchBrand" name="txtSearchBrand" placeholder="Search Game">
                        </form>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="app-grid-title">
                            <h4>Total <?php echo $total;?></h4>
                            <div class="tools">
                                <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['adnewgame']); ?>">Create New</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(isset($models) && !empty($models) && count($models)>0){?>
                <div class="app-scrollable">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 15%;">Name</th>
                                <th style="width: 15%;">Description</th>
                                <th style="width: 15%;">Thumb</th>
                                <th style="width: 15%;">Alter Thumb</th>
                                <th style="width: 15%;">Category</th>
                                <th style="width: 15%;">Provider</th>
                                <th style="width: 15%;">Iframe URL</th>
                                <th style="width: 15%;">Iframe Height</th>
                                <th style="width: 15%;">Iframe Width</th>
                                <th style="width: 15%;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for($i=0;$i<count($models);$i++){?>
                            <tr>
                                <td><?php echo $models[$i]->tg_name;?></td>
                                <td><?php echo $models[$i]->tg_des;?></td>
                                <td><img style=" border: 1px solid #DDDDDD;border-radius: 5px;" width="50" height="50" src="<?php if(!empty($models[$i]->tg_thumb)) echo BASE_URL.'/cdnimg/'.$models[$i]->tg_thumb;else echo BASE_URL.'/images/'.'default.jpg'; ?>"></td>
                                <td><img style=" border: 1px solid #DDDDDD;border-radius: 5px;" width="50" height="50" src="<?php if(!empty($models[$i]->tg_rthumb)) echo BASE_URL.'/cdnimg/'.$models[$i]->tg_rthumb;else echo BASE_URL.'/images/'.'default.jpg'; ?>"></td>
                                <td><?php echo $models[$i]->c_name;?></td>
                                <td><?php echo $models[$i]->p_name;?></td>
                                <td><?php echo $models[$i]->tg_iurl;?></td>
                                <td><?php echo $models[$i]->tg_width;?></td>
                                <td><?php echo $models[$i]->tg_height;?></td>
                                <td class="text-right">
                                    <a style="" href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['adeditgame']).'/'.$models[$i]->tg_key; ?>">Edit</a>
                                    <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['addeletegame']).'/'.$models[$i]->tg_key; ?>">Delete</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php } ?>
                <div style="margin-top:20px;">

                    <?php
                    $this->widget('CLinkPager', array(
                        'pages' => $pages,
                    ))
                    ?>

                </div>
            </div>
        </div>
    </div>
</div>