<?php $this->beginContent('/layouts/panels/site_header'); ?>
<?php $this->endContent();ob_start(); ?>
<body>         

    <div id="main-container">


        <div id="fixed-header"><!--//-->
            <div id="head">
                <div id="headerSection">
                    <div id="menu-container">
                        <div id="menu">
                            <div id="mobile-button"><a href="javascript://">
                                    <img title="" src="<?php echo BASE_URL; ?>/images/mobile-button.png"></a>
                            </div>
                            <div id="promotion-button"><a href="javascript://">
                                    <img alt="undefined" title="" src="<?php echo BASE_URL; ?>/images/promotion-button.png"></a>
                            </div>
                        </div>
                        <div id="logo">
                            <a  href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_index']); ?>"><img width="316" height="130" alt="undefined" title="" src="<?php echo BASE_URL; ?>/images/logo4.png"></a>
                        </div>
                        <div id="headLinks">
                            <div id="user-section-container">
                                 <?php if (isset(Yii::app()->user->useremail) && Yii::app()->user->useremail) { ?> 
                                
                                <?php }else { ?>
                                    <div id="user-section">
                                        <form name="login-form" id="login-form" method="post" action="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_index']); ?>">
                                            <input name="txtEmail" id="txtEmail" maxlength="20" class="input-field" placeholder="Email" required="" type="text"> 
                                            <input name="txtPassword" maxlength="20" size="20" value="PASS" id="txtPassword" class="input-field" type="password"> 
                                            <input name="login-submit" id="login-submit" value="" class="button" type="submit">
                                        </form>
                                    </div>
                                <?php } ?>
                                <div id="user-section-links" <?php if (isset(Yii::app()->user->useremail) && Yii::app()->user->useremail) { ?> style="float:right;" <?php } ?>>
                                     <?php if (isset(Yii::app()->user->useremail) && Yii::app()->user->useremail) { ?> 
                                        
                                        <a  href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_logout']); ?>">Logout</a> 

                                       
                                    <?php } else { ?>
                                        <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_forgotpass']); ?>">Forgot Login</a>
                                        <div id="head-signup">
                                            <a class="lightbox" href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['si_signup']); ?>">
                                                <img title="" src="<?php echo BASE_URL; ?>/images/signup.png"> 
                                            </a>
                                        </div> 
                                        
                                    <?php }?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div id="contentSection">
            
        </div>	 

        <?php  
              $criteria = new CDbCriteria();
              $criteria->order = 'tc_id DESC';
              $allcategories =  Category::model()->findAll($criteria);
        ?>
        <?php  if(isset($allcategories) && !empty($allcategories) && count($allcategories)>0){?>
        <div id="horizontal-line">
            <ul>
                <?php for($i=0;$i<count($allcategories);$i++){?>
                <li>
                    <a class="active" href="javascript://" title="<?php echo $allcategories[$i]->tc_name;?> Games">
                        <img src="<?php echo BASE_URL; ?>/images/other.png"><span><?php echo $allcategories[$i]->tc_name;?></span>
                    </a>
                </li> 
                <?php }?>
            </ul>
        </div>
        <?php } ?>



        <div id="lower-body">
             <?php echo $content; ?>
        </div>
        
        <?php $this->beginContent('/layouts/panels/site_footer'); ?>
        <?php $this->endContent(); ?>

    </div>
</body>
</html>
