<div id="pageTitle">
    <h2 class="thick-title page-title-bar">Provider List
    
    <?php 
    /*$client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }*/
    //echo "<pre>";
    //print_r($ip_data);
    //exit();
    ?>
    
    </h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <form enctype="multipart/form-data" name="frmPhoneModel" id="frmPhoneModel" action="" method="post">
                            <input type="text" class="form-control" id="txtSearchBrand" name="txtSearchBrand" placeholder="Search Provider">
                        </form>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="app-grid-title">
                            <h4>Total <?php echo $total;?></h4>
                            <div class="tools">
                                <a href="<?php echo $this->createUrl(Yii::app()->params['AppUrls']['adnewprovider']); ?>">Create New</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if(isset($models) && !empty($models) && count($models)>0){?>
                <div class="app-scrollable">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 20%;">Name</th>
                                <th style="width: 15%;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for($i=0;$i<count($models);$i++){?>
                            <tr>
                                <td><?php echo $models[$i]->tp_name;?></td>
                                <td class="text-right">
                                    <a href="javascript://">Edit</a>
                                    <a href="javascript://">Delete</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php } ?>
                <div style="margin-top:20px;">

                    <?php
                    $this->widget('CLinkPager', array(
                        'pages' => $pages,
                    ))
                    ?>

                </div>
            </div>
        </div>
    </div>
</div>