<?php

/**
 * Site Controller.
 *
 */
class SiteController extends AppController {

    public $layout = 'sitewheader';

    public function actionIndex() {

        $this->render(Yii::app()->params['AppViews']['si_index']);
    }

    public function actionDashboard() {

        $this->render(Yii::app()->params['AppViews']['si_dashboard']);
    }

    public function actionSignin() {
        $this->layout = 'sitewheader';
        $model = new LoginForm('login');
        if (isset($_POST['txtEmail'])) {
            $model->tu_email = Helpers::getCleanValue($_POST['txtEmail']);
            $model->tu_password = Helpers::getCleanValue($_POST['txtPassword']);
            if ($model->validate() && $model->login()) {
                Helpers::$log_user_id = Yii::app()->user->getId();
                Helpers::$log_relation_key = Helpers::getUserKeyById(Helpers::$log_user_id);
                Helpers::$log_relation_table = 'tbl_users';
                Helpers::$log_type = LOG_LOGIN;
                Helpers::createLog();
                $this->redirect(array(Yii::app()->params['AppUrls']['si_dashboard']));
            }
        }
        $this->render(Yii::app()->params['AppViews']['si_signin'], array(
            'model' => $model,
        ));
    }

    public function actionPlay() {
        $game_key = '';
        if (isset($_GET['i']) && !empty($_GET['i'])) {
            $game_key = $_GET['i'];
        }
        $game_details = Helpers::getPlayGameDetailsByGameSlug($game_key);
        if (isset($game_details['tg_key'])) {
            
        } else {
            $this->redirect(array(Yii::app()->params['AppUrls']['si_index']));
        }
        Helpers::$log_user_id = Yii::app()->user->getId();
        if (Helpers::$log_user_id > 0) {
            
        } else {
            Helpers::$log_user_id = 0;
        }
        Helpers::$log_relation_key = $game_details['tg_key'];
        Helpers::$log_relation_table = 'tbl_games';
        Helpers::$log_type = LOG_PLAY;
        Helpers::createLog();
        $this->render(Yii::app()->params['AppViews']['si_play_game'], array(
            'game_details' => $game_details
        ));
    }

    public function actionContactus() {
        $this->layout = 'siteother';
        $this->render(Yii::app()->params['AppViews']['si_contactus']);
    }

    public function actionAboutus() {
        $this->layout = 'siteother';
        $this->render(Yii::app()->params['AppViews']['si_aboutus']);
    }

    public function actionResponsibly() {
        $this->layout = 'siteother';
        $this->render(Yii::app()->params['AppViews']['si_responsibly']);
    }

    public function actionTos() {
        $this->layout = 'siteother';
        $this->render(Yii::app()->params['AppViews']['si_tos']);
    }

    public function actionPrivacy() {
        $this->layout = 'siteother';
        $this->render(Yii::app()->params['AppViews']['si_privacy']);
    }

    public function actionMessage() {

        $this->render(Yii::app()->params['AppViews']['site_message']);
    }

    public function actionEmailcheck() {
        $model = new User;
        if (isset($_POST['tu_email'])) {
            $thisEmail = Helpers::getCleanValue(trim($_POST['tu_email']));
            $checkEmail = $model->find('tu_email=:tu_email', array(':tu_email' => $thisEmail));
            if (empty($checkEmail)) {
                echo "true";
            } else {
                echo "false";
            }
        } else {
            Yii::app()->user->setFlash('error', "You are trying to access invalid URL!");
            $this->redirect(array("user/error"));
        }
    }

    public function actionForgotpass() {
        $message = '';
        if (1) {
            if (isset($_POST['forgotpassbtn'])) {
                $email = Helpers::getCleanValue($_POST['tu_email']);
                $command = Yii::app()->db->createCommand("SELECT * From tbl_users where tu_email = '$email' and tu_status=1");
                $result = $command->queryRow();
                if (isset($result['tu_email'])) {
                    $code = uniqid('', true);
                    $findAct = Yii::app()->db->createCommand("UPDATE tbl_users SET `tu_fokey` = '$code' where tu_email = '$email'");
                    $findAct->execute();
                    $this->sendForgotpassEmail($email, $code);
                    $message = 'Please check your email to set your new password.';
                } else {
                    $message = 'Something is wrong. Please try again!';
                }
            } else {
                
            }
        }
        $model = new User;
        $this->layout = 'sitewheader';
        $this->render(Yii::app()->params['AppViews']['si_forgotpass'], array(
            'model' => $model,
            'message' => $message
        ));
    }

    public function actionSignup() {
        $model = new User('signup');
        $this->layout = 'sitewheader';
        $message = '';
        $success = false;
        if (isset($_POST['Submit'])) {
            if (isset($_POST['tu_email']) && isset($_POST['recaptcha_response_field']) && isset($_POST['tu_username']) && isset($_POST['tu_mobile']) && isset($_POST['tu_password'])) {
                $model->tu_email = Helpers::getCleanValue($_POST['tu_email']);
                $model->tu_username = Helpers::getCleanValue($_POST['tu_username']);
                $modeltu_password = md5(Helpers::getCleanValue($_POST['tu_password']));
                $model->tu_password = $modeltu_password;
                $model->tu_ackey = uniqid('', true);
                $model->tu_mobile = Helpers::getCleanValue($_POST['tu_mobile']);
                $model->tu_ip = $_SERVER['REMOTE_ADDR'];
                $model->tu_user_key = Helpers::getUnqiueKey();
                $model->tu_role = 1;
                $model->tu_created_at = date(DB_INSERT_TIME_FORMAT, time());



                $model->tu_dob = Helpers::getCleanValue($_POST['birthdate']);
                $model->tu_fname = Helpers::getCleanValue($_POST['tu_fname']);
                $model->tu_lname = Helpers::getCleanValue($_POST['tu_lname']);
                $model->tu_cur = Helpers::getCleanValue($_POST['tu_cur']);
                $model->tu_street = Helpers::getCleanValue($_POST['tu_street']);
                $model->tu_city = Helpers::getCleanValue($_POST['tu_city']);
                $model->tu_zip = Helpers::getCleanValue($_POST['tu_zip']);
                $model->tu_sex = Helpers::getCleanValue($_POST['tu_sex']);
                $model->tu_long_country = Helpers::getCleanValue($_POST['tu_long_country']);
                $client = @$_SERVER['HTTP_CLIENT_IP'];
                $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
                $remote = $_SERVER['REMOTE_ADDR'];
                $result = "Unknown";
                if (filter_var($client, FILTER_VALIDATE_IP)) {
                    $ip = $client;
                } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
                    $ip = $forward;
                } else {
                    $ip = $remote;
                }

                //$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));
                //if($ip_data && $ip_data->geoplugin_countryName != null)
                //{
                //$result = $ip_data->geoplugin_countryName;
                //$model->tu_long_country = $result;
                //}

                $expire = time() - 3600;
                setcookie("tu_username", '', $expire);
                setcookie("email", '', $expire);
                setcookie("mobile", '', $expire);
                setcookie("password", '', $expire);

                $expire = time() + 60 * 60 * 24 * 30;
                setcookie("tu_username", $model->tu_username, $expire);
                setcookie("email", $model->tu_email, $expire);
                setcookie("mobile", $model->tu_mobile, $expire);
                setcookie("password", $modeltu_password, $expire);



                $to = '';
                if ($model->save()) {
                    $this->sendRegisterEmail($model->tu_email, $to, $model->tu_ackey);
                    $message = 'Registration is successfull! Please check your email to activate.';
                    $expire = time() - 3600;
                    setcookie("tu_username", '', $expire);
                    setcookie("email", '', $expire);
                    setcookie("mobile", '', $expire);
                    setcookie("password", '', $expire);
                    $success = true;
                } else {
                    
                }
            } else {
                if ($model->save()) {
                    
                } else {
                    
                }
            }
        }
        $command = Yii::app()->db->createCommand("SELECT * FROM `tbl_country` order by name asc");
        $allcountries = $command->queryAll();

        $this->render(Yii::app()->params['AppViews']['si_signup'], array(
            'model' => $model,
            'message' => $message,
            'success' => $success,
            'allcountries' => $allcountries
        ));
    }

    public function actionActivepassword() {
        $this->layout = 'sitewheader';
        $model = new User;
        $message = '';
        if (isset($_POST['activepassbtn'])) {
            if (isset($_POST['activepassbtn'])) {
                $email = Helpers::getCleanValue($_POST['emailsignup']);
                $password = md5(Helpers::getCleanValue($_POST['passwordsignup']));
                $passkey = Helpers::getCleanValue($_POST['password_key']);
                $command = Yii::app()->db->createCommand("SELECT * From tbl_users where tu_email = '$email' and tu_fokey ='$passkey'");
                $result = $command->queryRow();
                if (isset($result['tu_email'])) {
                    $findAct = Yii::app()->db->createCommand("UPDATE tbl_users SET `tu_password` = '$password',tu_fokey ='' where tu_email = '$email'");
                    $findAct->execute();
                    $message = 'Your new password has been activated!';
                } else {
                    $message = 'Email address is not found!';
                }
            } else {
                $message = 'Something is wrong. Please try again.';
            }
        } else {
            if (isset($_GET['passkey']) && !empty($_GET['passkey'])) {
                $passkey = Helpers::getCleanValue($_GET['passkey']);
                $command = Yii::app()->db->createCommand("SELECT * From tbl_users where tu_fokey   = '$passkey'");
                $result = $command->queryRow();
                if (isset($result['tu_fokey'])) {
                    
                } else {
                    $this->redirect(array('site/error'));
                }
            } else {
                $this->redirect(array('site/error'));
            }
        }
        $this->render(Yii::app()->params['AppViews']['active_password'], array(
            'model' => $model,
            'passkey' => $passkey,
            'message' => $message,
        ));
    }

    public function actionChangepassword() {
        $this->layout = 'sitewheader';
        $model = new User;
        if (Yii::app()->getRequest()->getIsAjaxRequest()) {
            if (isset($_POST['changepassbtn'])) {
                $user_id = Yii::app()->user->getId();
                if (isset($_POST['passwordsignup']) && isset($_POST['passwordsignup_confirm'])) {
                    $password = md5(Helpers::getCleanValue($_POST['passwordsignup']));
                    $findAct = Yii::app()->db->createCommand("UPDATE tbl_users SET `tu_password` = '$password' where tu_id = $user_id");
                    $findAct->execute();
                    Yii::app()->user->setState('password', true);
                    echo CJSON::encode(array(
                        'status' => 'success'
                    ));
                } else {
                    
                }
            } else {
                
            }
        } else {
            $this->render(Yii::app()->params['AppViews']['change_password'], array(
                'model' => $model,
            ));
        }
    }

    public function actionVerifyuser() {
        $this->layout = 'sitewheader';
        $message = '';
        if (isset($_GET['token']) && isset($_GET['email'])) {
            $activkey = Helpers::getCleanValue($_GET['token']);
            $email = Helpers::getCleanValue($_GET['email']);
            if ($activkey && !empty($activkey) && !empty($email)) {
                $command = Yii::app()->db->createCommand("SELECT * From tbl_users where tu_email = '$email' and tu_ackey = '$activkey'");
                //echo "SELECT * From users where email = '$email' and activate_code = '$activkey'";exit();
                $result = $command->queryRow();
                if (isset($result['tu_email'])) {
                    if ($result['tu_status'] == 1) {
                        $message = "This account is already activated!";
                    } else {
                        $findAct = Yii::app()->db->createCommand("UPDATE tbl_users SET `tu_status` = '1' where tu_email = '$email' and tu_ackey = '$activkey'");
                        $findAct->execute();
                        $message = "Your account is successfully activated!";
                    }
                    $this->render(Yii::app()->params['AppViews']['verify_view'], array(
                        'message' => $message,
                    ));
                } else {
                    $this->redirect(array('site/error'));
                }
            } else {
                $this->redirect(array('site/error'));
            }
        } else {
            $this->redirect(array('site/error'));
        }
    }

    public function actionDofunction() {
        $this_user_id = Yii::app()->user->getId();
        if ($this_user_id > 0) {
            $model = UserOnline::model()->findByAttributes(array('tou_user_id' => $this_user_id));
            if (isset($model->tou_user_id)) {
                $model->tou_last_track = date(DB_INSERT_TIME_FORMAT, time());
                $model->save();
            } else {
                $model = new UserOnline;
                $model->tou_user_id = $this_user_id;
                $model->tou_last_track = date(DB_INSERT_TIME_FORMAT, time());
                $model->tou_key = Helpers::getUnqiueKey();
                $model->save();
            }
        }
    }

    public function actionLogout() {
        Helpers::$log_user_id = Yii::app()->user->getId();
        Helpers::$log_relation_key = Helpers::getUserKeyById(Helpers::$log_user_id);
        Helpers::$log_relation_table = 'tbl_users';
        Helpers::$log_type = LOG_LOGOUT;
        Helpers::createLog();
        $expire = time() - 3600;
        setcookie("tu_username", '', $expire);
        setcookie("email", '', $expire);
        setcookie("mobile", '', $expire);
        setcookie("password", '', $expire);
        Yii::app()->user->logout();
        $this->redirect(array(Yii::app()->params['AppUrls']['si_index']));
    }

    public function actionError() {
        $message = 'Something is wrong. Please try again!';
        $this->layout = 'sitewheader';
        $this->render(Yii::app()->params['AppViews']['si_error'], array(
            'message' => $message
        ));
    }

    public function sendForgotpassEmail($email = '', $code = '') {
        if (!empty($email) && !empty($code)) {
            $appMailEvents = new AppMailEvents;
            $appMailEvents->forgotPassEmail($email, '', $code);
        }
    }

    public function sendRegisterEmail($to = "", $toName = "", $token = "") {
        $appMailEvents = new AppMailEvents;
        $appMailEvents->registeremail($to, $toName, $token);
    }

}
