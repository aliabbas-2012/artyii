<script src="<?php echo BASE_URL; ?>/cdn/js/gamewise.js?t=1"></script>
<div id="pageTitle">
    <h2 class="thick-title page-title-bar">Report Game Wise</h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">

                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 15%;">Search Game</th>
                                    <th style="width: 15%;">User</th>
                                    <th style="width: 15%;">Country</th>
                                    <th style="width: 15%;">Order By</th>
                                </tr>
                            </thead>
                            <tbody>

                                <tr>
                                    <td>
                                        <input style="width:280px;float:left;" type="text" class="form-control" id="txtSearchBrand" name="txtSearchBrand" placeholder="Search Game">
                                        <button style="float:right;" type="button" id="btnSt" name="btnSt" class="btn btn-info">Search</button>

                                    </td>
                                   
                                    <td>
                                        <select id="tg_user" name="tg_user" class="form-control">
                                            <option value="0">All User</option>
                                            <?php if(isset($allusers) && !empty($allusers) && count($allusers)>0){?>
                                            <?php for ($i = 0; $i < count($allusers); $i++) { ?>
                                                <option  value="<?php echo $allusers[$i]['tu_id']; ?>"><?php echo $allusers[$i]['tu_username']; ?> (<?php echo $allusers[$i]['tu_email']; ?>)</option>
                                            <?php } ?>
                                        <?php } ?>
                                        </select>
                                    </td>
                                     <td>
                                        <select id="tg_cou" name="tg_cou" class="form-control">
                                            <option value="">All Country</option>
                                            <?php if(isset($allcountries) && !empty($allcountries) && count($allcountries)>0){?>
                                            <?php for ($i = 0; $i < count($allcountries); $i++) { ?>
                                                <option  value="<?php echo $allcountries[$i]['name']; ?>"><?php echo $allcountries[$i]['name']; ?></option>
                                            <?php } ?>
                                        <?php } ?>
                                        </select>
                                    </td>
                                    <td>
                                        <select id="tg_order" name="tg_order" class="form-control">
                                            <option value="0">Order By Game  Played ASC</option>
                                            <option value="1">Order By Game  Played DESC</option>
                                            <option value="2">Order By Times Played ASC</option>
                                            <option value="3">Order By Times Played DESC</option>
                                            <option value="4">Order By Game Name ASC</option>
                                            <option value="5">Order By Game Name DESC</option>
                                        </select>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>

                </div>

                <div class="app-scrollable">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 15%;">Name</th>
                                <th style="width: 15%;">Thumb</th>
                                <th style="width: 15%;">Unique Played</th>
                                <th style="width: 15%;">Total Played</th>
                            </tr>
                        </thead>
                        <tbody id="append_grid_report">

                        </tbody>
                    </table>
                </div>
               <div class="disnone" id="seemore" style="position: relative;text-align: center; margin-top: 10px;">
                    <a id="viewmoretest" style="font-size:20px;text-decoration: lawngreen;color:green;margin:0 auto;text-align: center;" href="javascript://">View More</a>
                </div>

            </div>
        </div>
    </div>
</div>


<script id="tmpl_show_my_report" type="text/x-jquery-tmpl">
    <tr>
        <td>${tg_name}</td>
        <td><img style=" border: 1px solid #DDDDDD;border-radius: 5px;" width="50" height="50" src="<?php if(1) echo BASE_URL.'/cdnimg';?>/${tg_thumb}"></td>
        <td>${total_un_played}</td>
        <td>${total_played}</td>
    </tr>
</script>