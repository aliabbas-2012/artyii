<?php
Yii::import('application.extensions.apputility.AppUtility');
Yii::import('application.extensions.appevents.AppMailEvents');
class Controller extends CController
{
	
	public $menu=array();
	
	
}