<div id="pageTitle">
    <h2 class="thick-title page-title-bar">Error</h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
               Something is wrong. Please try again latter.
            </div>
        </div>
    </div>
</div>