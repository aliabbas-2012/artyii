<div id="pageTitle">
    <h2 class="thick-title page-title-bar">Online User List</h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <input type="text" class="form-control" id="txtSearchBrand" name="txtSearchBrand" placeholder="Search User">
                    </div>
                </div>
                <?php if(isset($models) && !empty($models) && count($models)>0){?>
                <div class="app-scrollable">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 15%;">User Name</th>
                                <th style="width: 15%;">Email</th>
                                <th style="width: 15%;">Mobile</th>
                                <th style="width: 15%;">Country</th>
                                <th style="width: 15%;">Created At</th>
                                <th style="width: 15%;">Total Played</th>
                                <th style="width: 15%;">Total Times</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for($i=0;$i<count($models);$i++){?>
                            <tr>
                                <td><?php echo $models[$i]['tu_username'];?></td>
                                <td><?php echo $models[$i]['tu_email'];?></td>
                                <td><?php echo $models[$i]['tu_mobile'];?></td>
                                <td><?php echo $models[$i]['tu_long_country'];?></td>
                                <td><?php echo $models[$i]['tu_created_at'];?></td>
                                <td><?php echo $models[$i]['total_un_played'];?> unique games</td>
                                <td><?php echo $models[$i]['total_played'];?> times</td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php } ?>
                
            </div>
        </div>
    </div>
</div>