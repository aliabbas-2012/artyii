<div id="pageTitle">
    <h2 class="thick-title page-title-bar">Order Games </h2>
</div>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="wrapper-box">
            <div class="wrapper-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <b style="color:Green;">Drag and drop to order games. Games will be arrange to user whats you are looking here.</b>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6">
                        <div class="app-grid-title">
                            <h4>Total <?php echo $total; ?></h4>

                        </div>
                    </div>
                </div>
                <?php if (isset($models) && !empty($models) && count($models) > 0) { ?>
                    <div class="app-scrollable">
                        <ul id="sortable">
                            <?php for ($i = 0; $i < count($models); $i++) { ?>
                                <li id="<?php echo $models[$i]->tg_id;?>" class="ui-state-default">
                                    <img class="lazy" src="<?php echo BASE_URL . '/images/' . 'default.jpg'; ?>" style=" border: 1px solid #DDDDDD;border-radius: 5px;" width="50" height="50" data-original="<?php
                                         if (!empty($models[$i]->tg_thumb))
                                             echo BASE_URL . '/cdnimg/' . $models[$i]->tg_thumb;
                                         else
                                             echo BASE_URL . '/images/' . 'default.jpg';
                                         ?>">
                                </li>

    <?php } ?>
                        </ul>
                    </div>
<?php } ?>

            </div>
        </div>
    </div>
</div>


<script>
    $(function() {
        $("img.lazy").lazyload();
        $('#sortable').sortable({
            update: function(event, ui) {
                var newOrder = $(this).sortable('toArray').toString();
                $.get('savegameorder', {order:newOrder});
            }
        });
        $("#sortable").disableSelection();
    });
</script>
